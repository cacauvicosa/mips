#include <gtest/gtest.h>

#include "kernel/yosys.h"
#include "kernel/log.h"

YOSYS_NAMESPACE_BEGIN

TEST(KernelLogTest, logvValidValues)
{
	//TODO: Implement log test
	EXPECT_EQ(7, 7);
}

YOSYS_NAMESPACE_END
